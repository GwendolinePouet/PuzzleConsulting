<?php
include('includes/header.php');
require('php/config.php');
?>

<main class="clearfix staffing-page">
    <section class="entry full-section">
        <article class="clearfix staffing-indications container">
            <h1>Avant de commencer</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean nec odio quis eros posuere ullamcorper. Vivamus auctor placerat urna, eu imperdiet metus auctor quis. Ut lacinia a augue eu dignissim. Proin vestibulum ligula libero, nec malesuada dui vehicula in. Phasellus vitae tempor nisl. Morbi nibh nulla, semper quis imperdiet at, feugiat vel quam. Morbi sem mauris, viverra congue interdum eu, convallis et purus. Pellentesque dictum, turpis vitae interdum dapibus, dolor turpis consectetur metus, in viverra lorem nulla ac dui. Nulla odio ex, maximus ut nisl a, lobortis ullamcorper dolor. Sed ac ligula id orci porttitor dapibus vitae ut orci. Pellentesque a purus id nibh pulvinar laoreet. </p>
            <p> Nam accumsan dui sit amet velit sollicitudin dapibus. Praesent euismod elit sed velit vulputate, at facilisis diam imperdiet. In felis mauris, semper non pharetra vitae, molestie eu nisl. Aenean faucibus pretium porta. Duis vel faucibus ligula, non eleifend diam. Curabitur at neque sit amet magna volutpat porttitor. Duis tincidunt dolor tellus, pulvinar vestibulum turpis congue in. </p>
            <p>Phasellus venenatis erat id nisi malesuada, non faucibus lectus ultricies. In tincidunt, purus at lobortis ultricies, dolor mi porta lectus, a rutrum nisi nulla vel massa. Maecenas ut dignissim turpis.</p>
            <a href="test-rh.php" class="start-btn start-form">Commencer</a>
        </article>
    </section>
</main>

<?php include('includes/footer.php'); ?>
