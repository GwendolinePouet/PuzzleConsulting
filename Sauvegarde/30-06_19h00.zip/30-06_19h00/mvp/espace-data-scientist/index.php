<?php


    $title = "Espace Data Scientist, postes valorisant à pourvoir";
    $description = "Puzzle propose de nombreux postes de Data Scientists, Data Analytics et experts en Business Intelligence. De nombreux challenges et missions diverses, le tout dans une ambiance startup vous attendent. ";
    $keywords = "data scientist, business intelligence, solutions it, recrutement, science des données";

    include('includes/header.php');
?>

<section class="sct-entry ds-sct-entry">
    <div class="slogan-container container">
        <h1 class="slogan-title">Vivez l'expérience Puzzle</h1>
        <p class="slogan-txt">Puzzle a créé cet espace pour vous, jeunes <strong>Data Scientist</strong>.<br>Ambiance startup, multiples challenges et missions diversifiés dans de nombreux secteurs d'activité n'attendent plus que vous !</p>
    </div>
    <div class="scroll-container">
        <p class="scroll-txt">Êtes-vous prêts à tous les défis ?</p>
        <a class="scroll-calltoaction" href="#">

        </a>
    </div>
</section>
<section class="sct-split ds-sct-1">
    <div class="split-box-img">
        <img src="assets/img/test-ds.jpg" alt="Environnement personalisé pour Data Scientist" title="Environnement personalisé pour Data Scientist">
    </div>
    <article class="split-box-content txt-content-style ">
        <h2>Une aventure inédite</h2>
        <p class="split-subtitle">Envie de changement&nbsp;?</p>
        <p>Marre des trop grands espaces&nbsp;? De ne connaître que 10% des noms des employés&nbsp;? De ne pas être reconnue à votre juste valeur&nbsp;?</p>
        <p class="split-subtitle">Respirez&nbsp;!</p>
        <p>Découvrez le monde des PME/PMI, qui ne demandent qu'à se développer et vivre avec vous une aventure inédite&nbsp;!</p>
    </article>
</section>
<section class="sct-split ds-sct-2">

    <article class="split-box-content txt-content-style ">
        <h2>Environnement personalisé</h2>
        <p class="split-subtitle">Au goût de tous et de toutes</p>
        <p>Profitez d'un espace de travail à votre goût.<br>Ici, c'est vous qui choisissez !</p>
    </article>
    <div class="split-box-img">
        <img src="assets/img/test-ds.jpg" alt="Environnement personalisé pour Data Scientist" title="Environnement personalisé pour Data Scientist">
    </div>
</section>

<?php
    include('includes/footer.php');
?>
