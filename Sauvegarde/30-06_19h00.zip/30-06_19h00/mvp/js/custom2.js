$(function(){
    $("#btimportcv").on("click",function(){               //Pour l import du cv
        $(this).hide();
        $("#importcv").show();
    });

    //var nbE = 1;
    //
    //$( ".ecran3" ).hover(
    //    function(){
    //        nbE == 2;
    //    }
    //);
    //
    //$( ".ecran"+nbE ).hover(
    //    function() {
    //        //$( ".p2" ).addClass( "active-point" );
    //        $('.p'+nbE).addClass('active-point');
    //    }, function() {
    //        $('#point .active-point').removeClass('active-point');
    //    }
    //);


    $('.icon-menu').click(function(){       //burger menu
        $('nav ul').slideToggle(1000);
    })

    //$(window).on('scroll', function() {
    //    console.log($(this).scrollTop());
    //    if ($(this).scrollTop() > 150 ) {
    //        $('.nav').animate({opacity : 1}, 10,function() {
    //            $(this).addClass('visible');
    //        });
    //    } else if ($(this).scrollTop() <= 150 ) {
    //        $('.nav').animate({opacity : 0}, 10 ,  function() {
    //            $(this).removeClass('visible');
    //        });
    //    }
    //});

    $(window).on('scroll', function() {
        console.log($(this).scrollTop());
        if ($(this).scrollTop() > 150 ) {
                $('.nav').addClass('visible');
        } else if ($(this).scrollTop() <= 150 ) {
                $('.nav').removeClass('visible');
        }
    });


    //remet le ul en display block apres avoir ete mis en display none avec jquery quand on clic sur le burger au format mobile. Le cas de figure n'est pas sencé se produire et la portion de code suivante ne fait qu'alourdir inutilement le code
    $(window).resize(function(){
        var w = $(window).width();
        if (w > 640){
            $("nav ul").show();
        }
    })

    $( ".ecran1" ).hover(               //Version barbare pour les points
        function() {
            $('.p1').addClass('active-point');
        }, function() {
            $('#point .active-point').removeClass('active-point');
        }
    );
    $( ".ecran2" ).hover(
        function() {
            $('.p2').addClass('active-point');
        }, function() {
            $('#point .active-point').removeClass('active-point');
        }
    );
    //$( ".ecran3" ).hover(
    //    function() {
    //        $('.p3').addClass('active-point');
    //    }, function() {
    //        $('#point .active-point').removeClass('active-point');
    //    }
    //);

    $('.ecran-form').on({                    //pour faire apparaitre le logo tournant
        mouseenter: function(){
            $(".p3").addClass('active-point-form');
            $('.p2').addClass('active-point-form-circle');
            $('.p1').addClass('active-point-form-circle');
        },
        mouseleave: function(){
            $(".p3").removeClass('active-point-form');
            $('.p2').removeClass('active-point-form-circle');
            $('.p1').removeClass('active-point-form-circle');
        }
    });

    //$(".plusData").on("click", function () {
    //    $(".article1").hide();
    //    $("#myDiv").toggle("slide");
    //});
    //$(".moinsData").on("click", function () {
    //    $("#myDiv").toggle("slide");
    //    $(".article1").show(500);
    //});

    $(".plusData").on("click", function () {                //bouton pour data scientist sur laccueil
        $(".ecran2").hide(300);
        $(".slideData").toggle("slide");
    });
    $(".moinsData").on("click", function () {
        $(".slideData").toggle("slide");
        $(".ecran2").show(900);
    });

    $(".plusEntrep").on("click", function () {                //bouton pour data entrepreneur sur laccueil
        $(".article1, .article2").hide(800);
        $(".slideEntrep").toggle("slide");
    });
    $(".moinsEntrep").on("click", function () {
        $(".slideEntrep").toggle("slide");
        $(".article1, .article2").show(900);
    });


    $('h1 img').on({                    //pour faire apparaitre le logo tournant
        mouseenter: function(){
            $(".logoCircle").show();
        },
        mouseleave: function(){
            $(".logoCircle").hide();
        }
    });

    $('.btBlue1').on({                    //pour faire apparaitre le logo tournant
        mouseenter: function(){
            $("span[bt-bleu]").addClass('bt-bleu-hover');
        },
        mouseleave: function(){
            $("span[bt-bleu]").removeClass('bt-bleu-hover');
        }
    });
    $('.btBlue2').on({                    //pour faire apparaitre le logo tournant
        mouseenter: function(){
            $("span[bt-bleu2]").addClass('bt-bleu-hover');
        },
        mouseleave: function(){
            $("span[bt-bleu2]").removeClass('bt-bleu-hover');
        }
    });



});

$(function(){

    var nbQ = 1;
    var repok = 0;
    //alert(nbQ);


    $('.timer').startTimer({                    //lancement du timer
        onComplete: function(element){          //quand le timer arrive a 0
            element.addClass('is-complete');    //ajout de la classe iscomplet
            $('.compteur-quest').html(nbQ);     //affiche le compteur sur la page

            $(".quest"+(nbQ-1)).hide();         //quand le compteur prend +1, la question disparait
            $(".quest"+nbQ).show();             //quand le compteur est egal a la question elle apparait
            nbQ++;                              //le compteur prend +1

        },
        loop: true,
        loopInterval: 2,
    });
    var answer1;
    var answer2;
    var answer3;
    var answer4;


    //$(".correct").click(function(){
    //    $('.compteur-repok').html(repok);
    //    repok++;
    //}
    $(".quest1 .answers").on("click",function(e){
        answer1 = $(this).attr('id');
        answer1 = answer.replace('ans-','');
    });
    $(".quest2 .answers").on("click",function(e){
        answer2 = $(this).attr('id');
        answer2 = answer.replace('ans-','');
    });
    $(".quest3 .answers").on("click",function(e){
        answer3 = $(this).attr('id');
        answer3 = answer.replace('ans-','');
    });
    $(".quest4 .answers").on("click",function(e){
        answer4 = $(this).attr('id');
        answer4 = answer.replace('ans-','');
    });
    $(".validate").on("click", function(e){
        e.preventDefault();
    });


    //$(".answers").click(function(){
    //    nbQ++;
    //});




});
