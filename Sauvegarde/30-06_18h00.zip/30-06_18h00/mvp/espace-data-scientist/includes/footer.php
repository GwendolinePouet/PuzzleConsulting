</main>

<?php

if($useJquery==true)
{
    echo'

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
    
    
    ';
    if($moreJS != ""){

        echo $moreJS;
    }
    echo'

    <script src="assets/js/custom.js"></script>
    
    
    ';
}

?>


</body>
</html>